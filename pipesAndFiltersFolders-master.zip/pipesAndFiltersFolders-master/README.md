# pipesAndFiltersFolders
Sistema que busca en una carpeta archivos por nombre desarrollado bajo el estilo arquitectónico pipes and filters
